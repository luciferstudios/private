import React, { useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import PageContentBlock from '@/components/elements/PageContentBlock';
import { enabled, errMsg, readText, readBinary, sendCommand, Disabled } from '../lib';
import { gunzip, readNbt } from '../nbt';

interface Known { uuid: string; nick: string; whitelisted?: boolean; op?: boolean; banned?: boolean; }

const ACTIONS: [string, string][] = [
    ['Whitelist add', 'whitelist add'], ['Whitelist remove', 'whitelist remove'],
    ['OP', 'op'], ['De-OP', 'deop'], ['Kick', 'kick'], ['Ban', 'ban'], ['Unban', 'pardon'],
];
const MODES = ['survival', 'creative', 'adventure', 'spectator'];
const ARMOR: [number, string][] = [[103, 'Helmet'], [102, 'Chestplate'], [101, 'Leggings'], [100, 'Boots'], [-106, 'Offhand']];

const readJson = async (uuid: string, file: string): Promise<any[]> => {
    try { return JSON.parse(await readText(uuid, file)); } catch { return []; }
};

const Slot = ({ item }: { item?: any }) => {
    const [failed, setFailed] = useState(false);
    const cls = 'bd-slot';
    if (!item) return <div className={cls} />;
    const id = String(item.id).replace('minecraft:', '');
    const cnt = item.count ?? item.Count ?? 1;
    return (
        <div className={cls} title={`${id} x${cnt}`}>
            {!failed
                ? <img src={`https://minecraft-api.vercel.app/images/items/${id}.png`} onError={() => setFailed(true)} width={32} height={32} />
                : <span className={'bd-slot-text'}>{id.replace(/_/g, ' ').slice(0, 14)}</span>}
            {cnt > 1 && <span className={'bd-slot-count'}>{cnt}</span>}
        </div>
    );
};

const Grid = ({ items, slots }: { items: any[]; slots: number[] }) => (
    <div className={'bd-grid'}>
        {slots.map((s) => <Slot key={s} item={items.find((i) => i.Slot === s)} />)}
    </div>
);

const range = (a: number, b: number) => Array.from({ length: b - a + 1 }, (_, i) => a + i);

export default () => {
    const uuid = ServerContext.useStoreState((s) => s.server.data!.uuid);
    const socket = ServerContext.useStoreState((s) => s.socket.instance);
    const status = ServerContext.useStoreState((s) => s.status.value);
    const [who, setWho] = useState('');
    const [msg, setMsg] = useState('');
    const [online, setOnline] = useState<string[]>([]);
    const [max, setMax] = useState(0);
    const [known, setKnown] = useState<Known[]>([]);
    const [filter, setFilter] = useState('');
    const [sel, setSel] = useState<Known | null>(null);
    const [detail, setDetail] = useState<any>(null);
    const [detailErr, setDetailErr] = useState('');
    const [giveId, setGiveId] = useState('diamond');
    const [giveN, setGiveN] = useState('1');

    const loadKnown = async () => {
        const map: Record<string, Known> = {};
        const add = (arr: any[], flag: string) => arr.forEach((p) => {
            if (!p.uuid || !p.name) return;
            map[p.uuid] = { ...(map[p.uuid] || { uuid: p.uuid, nick: p.name }), [flag]: true };
        });
        add(await readJson(uuid, '/usercache.json'), 'seen');
        add(await readJson(uuid, '/whitelist.json'), 'whitelisted');
        add(await readJson(uuid, '/ops.json'), 'op');
        add(await readJson(uuid, '/banned-players.json'), 'banned');
        setKnown(Object.values(map).sort((a, b) => a.nick.localeCompare(b.nick)));
    };

    useEffect(() => { loadKnown(); }, []);

    // Live online list: ask the console for "list" and read the answer.
    useEffect(() => {
        if (!socket || status !== 'running') { setOnline([]); return; }
        const onLine = (line: string) => {
            const clean = String(line).replace(/\u001b\[[0-9;]*m/g, '');
            const m = clean.match(/There are (\d+) of a max of (\d+) players online:?\s*(.*)$/i);
            if (m) {
                setMax(parseInt(m[2], 10));
                setOnline(m[3] ? m[3].split(',').map((s) => s.trim()).filter(Boolean) : []);
            }
        };
        socket.addListener('console output', onLine);
        const poll = () => socket.send('send command', 'list');
        poll();
        const t = setInterval(poll, 30000);
        return () => { socket.removeListener('console output', onLine); clearInterval(t); };
    }, [socket, status]);

    if (!enabled('players')) return <PageContentBlock title={'Player Manager'}><p>{Disabled}</p></PageContentBlock>;

    const run = async (cmd: string, dest: string) => {
        if (!/^[A-Za-z0-9_.]{1,32}$/.test(dest)) return setMsg('Enter a valid username.');
        try {
            await sendCommand(uuid, `${cmd} ${dest}`);
            setMsg(`Sent: ${cmd} ${dest}`);
            setTimeout(loadKnown, 1500);
        } catch (e) {
            setMsg(`Failed (server must be online): ${errMsg(e)}`);
        }
    };

    const raw = async (cmd: string) => {
        try { await sendCommand(uuid, cmd); setMsg(`Sent: ${cmd}`); } catch (e) { setMsg(`Failed: ${errMsg(e)}`); }
    };

    const open = async (p: Known) => {
        setSel(p); setDetail(null); setDetailErr('');
        let level = 'world';
        try {
            const m = (await readText(uuid, '/server.properties')).match(/^level-name=(.*)$/m);
            if (m && m[1].trim()) level = m[1].trim();
        } catch { /* default */ }
        let nbt: any = null;
        for (const path of [`/${level}/players/data/${p.uuid}.dat`, `/${level}/playerdata/${p.uuid}.dat`]) {
            try { nbt = readNbt(await gunzip(await readBinary(uuid, path))); break; } catch { /* try next */ }
        }
        if (!nbt) return setDetailErr('No saved data for this player yet (they may never have joined).');
        let stats: any = {};
        for (const path of [`/${level}/stats/${p.uuid}.json`]) {
            try { stats = JSON.parse(await readText(uuid, path)).stats || {}; } catch { /* none */ }
        }
        const custom = stats['minecraft:custom'] || {};
        setDetail({
            nbt,
            inv: nbt.Inventory || [],
            ender: nbt.EnderItems || [],
            playTicks: custom['minecraft:play_time'] ?? custom['minecraft:play_one_minute'] ?? 0,
            deaths: custom['minecraft:deaths'] ?? 0,
        });
    };

    const saveAll = async () => {
        await raw('save-all flush');
        setTimeout(() => sel && open(sel), 2500);
    };

    const shown = known.filter((k) => k.nick.toLowerCase().includes(filter.toLowerCase()));
    const isOnline = (n: string) => online.some((o) => o.toLowerCase() === n.toLowerCase());
    const modeName = ['Survival', 'Creative', 'Adventure', 'Spectator'];

    return (
        <PageContentBlock title={'Player Manager'}>
            <div className={'bd-card'}>
                <input className={'bd-input'} value={who} onChange={(e) => setWho(e.target.value)} placeholder={'Username'} />
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '.5rem', marginTop: '.75rem' }}>
                    {ACTIONS.map(([label, cmd]) => <button key={cmd} className={'bd-btn'} onClick={() => run(cmd, who)}>{label}</button>)}
                </div>
                {msg && <p style={{ marginTop: '.75rem' }}>{msg}</p>}
            </div>

            <div className={'bd-card'}>
                <strong>Online now ({online.length}{max ? ` / ${max}` : ''})</strong>
                {status !== 'running' && <p style={{ opacity: 0.7 }}>Server is not running.</p>}
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '.75rem', marginTop: '.75rem' }}>
                    {online.map((n) => {
                        const k = known.find((x) => x.nick.toLowerCase() === n.toLowerCase());
                        return (
                            <div key={n} className={'bd-player'} onClick={() => k && open(k)}>
                                <img src={`https://mc-heads.net/avatar/${n}/40`} width={40} height={40} style={{ borderRadius: 8 }} />
                                <span>{n}</span>
                            </div>
                        );
                    })}
                </div>
                <p style={{ opacity: 0.6, fontSize: '.8rem', marginTop: '.75rem' }}>Refreshes every 30 seconds while this page is open.</p>
            </div>

            {sel && (
                <div className={'bd-card'}>
                    <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                        <img src={`https://mc-heads.net/avatar/${sel.nick}/64`} width={64} height={64} style={{ borderRadius: 10 }} />
                        <div style={{ flex: 1 }}>
                            <strong style={{ fontSize: '1.2rem' }}>{sel.nick}</strong> {isOnline(sel.nick) ? '(online)' : '(offline)'}
                            <div style={{ opacity: 0.6, fontSize: '.75rem' }}>{sel.uuid}</div>
                        </div>
                        <button className={'bd-btn'} onClick={saveAll}>Save &amp; reload</button>
                    </div>
                    {detailErr && <p style={{ marginTop: '.75rem' }}>{detailErr}</p>}
                    {detail && (
                        <>
                            <p style={{ marginTop: '.75rem', opacity: 0.85 }}>
                                Health {Math.round(detail.nbt.Health ?? 0)} · Food {detail.nbt.foodLevel ?? '?'} · XP level {detail.nbt.XpLevel ?? 0}
                                {' · '}{modeName[detail.nbt.playerGameType] || 'Unknown'} · Deaths {detail.deaths}
                                {detail.playTicks ? ` · Played ${(detail.playTicks / 72000).toFixed(1)} h` : ''}
                                {detail.nbt.Pos ? ` · Last at ${detail.nbt.Pos.map((n: number) => Math.round(n)).join(', ')}` : ''}
                            </p>
                            <h4 style={{ marginTop: '1rem' }}>Inventory</h4>
                            <div style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap' }}>
                                <div>
                                    <Grid items={detail.inv} slots={range(9, 35)} />
                                    <div style={{ height: 8 }} />
                                    <Grid items={detail.inv} slots={range(0, 8)} />
                                </div>
                                <div>
                                    {ARMOR.map(([s, label]) => (
                                        <div key={s} style={{ display: 'flex', alignItems: 'center', gap: '.5rem', marginBottom: 4 }}>
                                            <Slot item={detail.inv.find((i: any) => i.Slot === s)} /><span style={{ opacity: 0.7, fontSize: '.8rem' }}>{label}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                            <h4 style={{ marginTop: '1rem' }}>Ender chest</h4>
                            <Grid items={detail.ender} slots={range(0, 26)} />
                        </>
                    )}
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '.5rem', marginTop: '1rem' }}>
                        {MODES.map((m) => <button key={m} className={'bd-btn'} onClick={() => raw(`gamemode ${m} ${sel.nick}`)}>{m}</button>)}
                        <button className={'bd-btn'} onClick={() => window.confirm(`Clear ${sel.nick}'s inventory?`) && raw(`clear ${sel.nick}`)}>Clear inventory</button>
                        <button className={'bd-btn'} onClick={() => raw(`kill ${sel.nick}`)}>Kill</button>
                    </div>
                    <div style={{ marginTop: '.75rem' }}>
                        <input className={'bd-input'} style={{ width: '12rem' }} value={giveId} onChange={(e) => setGiveId(e.target.value.trim())} placeholder={'item id'} />
                        <input className={'bd-input'} style={{ width: '5rem', marginLeft: '.5rem' }} value={giveN} onChange={(e) => setGiveN(e.target.value.trim())} />
                        <button className={'bd-btn'} style={{ marginLeft: '.5rem' }}
                                onClick={() => /^[a-z0-9_:.\/-]+$/.test(giveId) && /^\d{1,4}$/.test(giveN) ? raw(`give ${sel.nick} ${giveId} ${giveN}`) : setMsg('Invalid item or amount')}>
                            Give item
                        </button>
                    </div>
                    <p style={{ opacity: 0.6, fontSize: '.8rem', marginTop: '.5rem' }}>
                        Inventory data is read from the world save, so online players may be a few minutes behind until you press Save &amp; reload.
                    </p>
                </div>
            )}

            <div className={'bd-card'}>
                <strong>All players ({known.length})</strong>
                <input className={'bd-input'} style={{ marginLeft: '1rem' }} value={filter} onChange={(e) => setFilter(e.target.value)} placeholder={'Filter…'} />
                {shown.map((k) => (
                    <div key={k.uuid} style={{ display: 'flex', alignItems: 'center', gap: '.75rem', marginTop: '.5rem' }}>
                        <img src={`https://mc-heads.net/avatar/${k.nick}/28`} width={28} height={28} style={{ borderRadius: 6 }} />
                        <span style={{ flex: 1 }}>
                            {k.nick}{isOnline(k.nick) ? ' 🟢' : ''}{k.op ? ' · OP' : ''}{k.whitelisted ? ' · whitelisted' : ''}{k.banned ? ' · banned' : ''}
                        </span>
                        <button className={'bd-btn'} onClick={() => open(k)}>View</button>
                        {k.whitelisted
                            ? <button className={'bd-btn'} onClick={() => run('whitelist remove', k.nick)}>Unwhitelist</button>
                            : <button className={'bd-btn'} onClick={() => run('whitelist add', k.nick)}>Whitelist</button>}
                        {k.banned
                            ? <button className={'bd-btn'} onClick={() => run('pardon', k.nick)}>Unban</button>
                            : <button className={'bd-btn'} onClick={() => run('ban', k.nick)}>Ban</button>}
                    </div>
                ))}
                <button className={'bd-btn'} style={{ marginTop: '.75rem' }} onClick={loadKnown}>Refresh</button>
            </div>
        </PageContentBlock>
    );
};

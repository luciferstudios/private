// Minimal gzip + NBT reader (enough for playerdata files).
export const gunzip = async (buf: ArrayBuffer): Promise<ArrayBuffer> => {
    const bytes = new Uint8Array(buf);
    if (bytes[0] !== 0x1f || bytes[1] !== 0x8b) return buf; // not gzipped
    const DS = (window as any).DecompressionStream;
    if (!DS) throw new Error('This browser cannot decompress player data');
    const stream = new Response(new Blob([buf]).stream().pipeThrough(new DS('gzip')));
    return stream.arrayBuffer();
};

export const readNbt = (buf: ArrayBuffer): any => {
    const v = new DataView(buf);
    const dec = new TextDecoder();
    let p = 0;

    const str = (): string => {
        const l = v.getUint16(p);
        p += 2;
        const s = dec.decode(new Uint8Array(buf, p, l));
        p += l;
        return s;
    };

    const payload = (t: number): any => {
        switch (t) {
            case 1: { const x = v.getInt8(p); p += 1; return x; }
            case 2: { const x = v.getInt16(p); p += 2; return x; }
            case 3: { const x = v.getInt32(p); p += 4; return x; }
            case 4: { const hi = v.getInt32(p); const lo = v.getUint32(p + 4); p += 8; return hi * 4294967296 + lo; }
            case 5: { const x = v.getFloat32(p); p += 4; return x; }
            case 6: { const x = v.getFloat64(p); p += 8; return x; }
            case 7: { const l = v.getInt32(p); p += 4 + l; return null; }
            case 8: return str();
            case 9: {
                const it = v.getInt8(p); p += 1;
                const l = v.getInt32(p); p += 4;
                const a: any[] = [];
                for (let i = 0; i < l; i++) a.push(payload(it));
                return a;
            }
            case 10: {
                const o: any = {};
                for (;;) {
                    const tt = v.getInt8(p); p += 1;
                    if (tt === 0) break;
                    const k = str();
                    o[k] = payload(tt);
                }
                return o;
            }
            case 11: { const l = v.getInt32(p); p += 4 + l * 4; return null; }
            case 12: { const l = v.getInt32(p); p += 4 + l * 8; return null; }
            default: throw new Error(`Unknown NBT tag ${t}`);
        }
    };

    const rootType = v.getInt8(p); p += 1;
    str();
    return payload(rootType);
};

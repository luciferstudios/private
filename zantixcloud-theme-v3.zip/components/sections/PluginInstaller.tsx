import React, { useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import PageContentBlock from '@/components/elements/PageContentBlock';
import { enabled, errMsg, mkdir, pull, remove, listDir, Disabled } from '../lib';

interface Hit { project_id: string; title: string; description: string; icon_url?: string; downloads: number; }

export default () => {
    const uuid = ServerContext.useStoreState((s) => s.server.data!.uuid);
    const [q, setQ] = useState('');
    const [gv, setGv] = useState('');
    const [hits, setHits] = useState<Hit[]>([]);
    const [installed, setInstalled] = useState<any[]>([]);
    const [msg, setMsg] = useState('');
    const [busy, setBusy] = useState('');

    const loadInstalled = async () => {
        try {
            setInstalled((await listDir(uuid, '/plugins')).filter((f) => f.is_file && /\.jar$/i.test(f.name)));
        } catch {
            setInstalled([]);
        }
    };

    useEffect(() => { loadInstalled(); }, []);

    if (!enabled('plugins')) return <PageContentBlock title={'Plugin Installer'}><p>{Disabled}</p></PageContentBlock>;

    const search = async () => {
        setMsg('');
        try {
            const facets: string[][] = [['project_type:plugin']];
            if (gv) facets.push([`versions:${gv}`]);
            const r = await fetch(`https://api.modrinth.com/v2/search?query=${encodeURIComponent(q)}&limit=15&facets=${encodeURIComponent(JSON.stringify(facets))}`);
            if (!r.ok) throw new Error(`Modrinth returned ${r.status}`);
            const d = await r.json();
            setHits(d.hits);
            if (!d.hits.length) setMsg('No plugins found.');
        } catch (e) {
            setMsg(`Search failed: ${errMsg(e)}`);
        }
    };

    const install = async (h: Hit) => {
        setBusy(h.project_id);
        setMsg('');
        try {
            const p = new URLSearchParams({ loaders: JSON.stringify(['paper', 'spigot', 'bukkit', 'purpur']) });
            if (gv) p.set('game_versions', JSON.stringify([gv]));
            const vr = await fetch(`https://api.modrinth.com/v2/project/${h.project_id}/version?${p.toString()}`);
            const versions = await vr.json();
            const file = versions[0]?.files?.find((f: any) => f.primary) ?? versions[0]?.files?.[0];
            if (!file) throw new Error(gv ? `No build for Minecraft ${gv}` : 'No compatible file found');
            try { await mkdir(uuid, '/', 'plugins'); } catch { /* already exists */ }
            await pull(uuid, file.url, '/plugins', file.filename);
            setMsg(`Installed ${file.filename}. Restart the server to load it.`);
            loadInstalled();
        } catch (e) {
            setMsg(`Install failed: ${errMsg(e)}`);
        }
        setBusy('');
    };

    const uninstall = async (file: string) => {
        if (!window.confirm(`Delete ${file}?`)) return;
        try {
            await remove(uuid, '/plugins', [file]);
            setMsg(`Deleted ${file}. Restart the server to unload it.`);
            loadInstalled();
        } catch (e) {
            setMsg(`Delete failed: ${errMsg(e)}`);
        }
    };

    return (
        <PageContentBlock title={'Plugin Installer'}>
            <div className={'bd-card'}>
                <input className={'bd-input'} value={q} onChange={(e) => setQ(e.target.value)} placeholder={'Search Modrinth plugins…'}
                       onKeyDown={(e) => e.key === 'Enter' && search()} />
                <input className={'bd-input'} style={{ marginLeft: '.5rem', width: '9rem' }} value={gv}
                       onChange={(e) => setGv(e.target.value.trim())} placeholder={'MC version (opt.)'} />
                <button className={'bd-btn'} style={{ marginLeft: '.5rem' }} onClick={search}>Search</button>
                {msg && <p style={{ marginTop: '.75rem' }}>{msg}</p>}
            </div>
            {hits.map((h) => (
                <div key={h.project_id} className={'bd-card'} style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                    {h.icon_url && <img src={h.icon_url} width={48} height={48} style={{ borderRadius: 10 }} />}
                    <div style={{ flex: 1 }}>
                        <strong>{h.title}</strong>
                        <div style={{ opacity: 0.7, fontSize: '.85rem' }}>{h.description}</div>
                    </div>
                    <button className={'bd-btn'} disabled={busy === h.project_id} onClick={() => install(h)}>
                        {busy === h.project_id ? 'Installing…' : 'Install'}
                    </button>
                </div>
            ))}
            <div className={'bd-card'}>
                <strong>Installed plugins ({installed.length})</strong>
                {installed.length === 0 && <p style={{ opacity: 0.7 }}>No .jar files found in /plugins.</p>}
                {installed.map((f) => (
                    <div key={f.name} style={{ display: 'flex', justifyContent: 'space-between', marginTop: '.5rem' }}>
                        <span>{f.name}</span>
                        <button className={'bd-btn'} onClick={() => uninstall(f.name)}>Delete</button>
                    </div>
                ))}
            </div>
        </PageContentBlock>
    );
};

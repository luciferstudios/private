<form action="" method="POST">
  <div class="box box-primary">
    <div class="box-header with-border"><h3 class="box-title">ZantixCloud Settings</h3></div>
    <div class="box-body">
      <div class="row">
        <div class="form-group col-md-4">
          <label class="control-label">Accent color</label>
          <input type="color" name="accent" class="form-control" value="{{ $accent }}">
        </div>
        <div class="form-group col-md-4">
          <label class="control-label">Google font name</label>
          <input type="text" name="font" class="form-control" value="{{ $font }}" placeholder="Poppins">
          <p class="text-muted small">Any family from fonts.google.com</p>
        </div>
        <div class="form-group col-md-4">
          <label class="control-label">Brand name</label>
          <input type="text" name="brand" class="form-control" value="{{ $brand }}">
        </div>
      </div>
      <div class="row">
        <div class="form-group col-md-3"><label><input type="checkbox" name="plugins" value="1" @if($plugins) checked @endif> Plugin installer</label></div>
        <div class="form-group col-md-3"><label><input type="checkbox" name="players" value="1" @if($players) checked @endif> Player manager</label></div>
        <div class="form-group col-md-3"><label><input type="checkbox" name="software" value="1" @if($software) checked @endif> Software/version manager</label></div>
      </div>
    </div>
    <div class="box-footer">
      @csrf
      @method('PATCH')
      <button class="btn btn-primary pull-right" type="submit">Save</button>
    </div>
  </div>
</form>

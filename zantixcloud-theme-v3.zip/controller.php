<?php

namespace Pterodactyl\Http\Controllers\Admin\Extensions\{identifier};

use Illuminate\View\View;
use Illuminate\View\Factory as ViewFactory;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\BlueprintFramework\Libraries\ExtensionLibrary\Admin\BlueprintAdminLibrary as BlueprintExtensionLibrary;

class {identifier}ExtensionController extends Controller
{
    public function __construct(
        private ViewFactory $view,
        private BlueprintExtensionLibrary $blueprint,
    ) {}

    public function index(): View
    {
        $b = $this->blueprint;
        $get = fn ($k, $d) => $b->dbGet('{identifier}', $k) ?: $d;

        return $this->view->make('admin.extensions.{identifier}.index', [
            'root' => '/admin/extensions/{identifier}',
            'blueprint' => $b,
            'accent' => $get('accent', '#1a86ff'),
            'font' => $get('font', 'Poppins'),
            'brand' => $get('brand', 'ZantixCloud'),
            'plugins' => $get('plugins', '1') === '1',
            'players' => $get('players', '1') === '1',
            'software' => $get('software', '1') === '1',
        ]);
    }

    public function update(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'accent' => ['required', 'regex:/^#[0-9a-fA-F]{6}$/'],
            'font' => ['required', 'regex:/^[A-Za-z0-9 ]{1,40}$/'],
            'brand' => ['required', 'string', 'max:40'],
        ]);

        foreach ($data as $k => $v) {
            $this->blueprint->dbSet('{identifier}', $k, $v);
        }
        foreach (['plugins', 'players', 'software'] as $flag) {
            $this->blueprint->dbSet('{identifier}', $flag, $request->has($flag) ? '1' : '0');
        }

        return redirect()->route('admin.extensions.{identifier}.index');
    }
}

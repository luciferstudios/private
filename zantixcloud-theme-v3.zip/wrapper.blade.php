@php
  $bdAccent = $blueprint->dbGet('{identifier}', 'accent') ?: '#1a86ff';
  $bdFont = preg_replace('/[^A-Za-z0-9 ]/', '', $blueprint->dbGet('{identifier}', 'font') ?: 'Poppins');
@endphp
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family={{ str_replace(' ', '+', $bdFont) }}:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
  :root { --bd-accent: {{ $bdAccent }}; --bd-font: '{{ $bdFont }}', system-ui, sans-serif; }
</style>
<link rel="icon" type="image/png" href="/extensions/bluedeck/favicon.png">
<style>
  /* Logo on login / auth pages */
  #app form[action*="login"]::before, #app .LoginFormContainer::before {
    content: ""; display: block; width: 160px; height: 160px; margin: 0 auto 1rem;
    background: url('/extensions/bluedeck/logo.png') center / contain no-repeat; border-radius: 16px;
  }
</style>
<script>
  window.BD = {
    plugins: {{ ($blueprint->dbGet('{identifier}', 'plugins') ?: '1') === '1' ? 'true' : 'false' }},
    players: {{ ($blueprint->dbGet('{identifier}', 'players') ?: '1') === '1' ? 'true' : 'false' }},
    software: {{ ($blueprint->dbGet('{identifier}', 'software') ?: '1') === '1' ? 'true' : 'false' }}
  };
</script>

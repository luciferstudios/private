import React, { useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import PageContentBlock from '@/components/elements/PageContentBlock';
import { enabled, errMsg, pull, remove, rename, listDir, readText, writeText, setVariable, newestFirst, Disabled } from '../lib';

interface Build { id: string; label: string; url?: string; }

const FILL = 'https://fill.papermc.io/v3/projects';
const PURPUR = 'https://api.purpurmc.org/v2/purpur';
const FABRIC = 'https://meta.fabricmc.net/v2/versions';
const MOJANG = 'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json';

const SOURCES: [string, string][] = [
    ['paper', 'Paper'], ['purpur', 'Purpur'], ['folia', 'Folia'], ['velocity', 'Velocity (proxy)'],
    ['fabric', 'Fabric'], ['vanilla', 'Vanilla'],
];

const getJson = async (url: string) => {
    const r = await fetch(url);
    if (!r.ok) throw new Error(`${new URL(url).host} returned ${r.status}`);
    return r.json();
};

const fmtSize = (n: number) => (n > 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.round(n / 1024)} KB`);

const listVersions = async (src: string): Promise<string[]> => {
    if (src === 'purpur') return (await getJson(PURPUR)).versions;
    if (src === 'fabric') return (await getJson(`${FABRIC}/game`)).filter((g: any) => g.stable).map((g: any) => g.version);
    if (src === 'vanilla') return (await getJson(MOJANG)).versions.filter((v: any) => v.type === 'release').map((v: any) => v.id);
    const d = await getJson(`${FILL}/${src}`);
    return Array.isArray(d.versions) ? d.versions : ([] as string[]).concat(...(Object.values(d.versions) as string[][]));
};

const listBuilds = async (src: string, ver: string): Promise<Build[]> => {
    if (src === 'purpur') {
        const d = await getJson(`${PURPUR}/${ver}`);
        return [...d.builds.all].reverse().map((b: string) => ({ id: b, label: `Build ${b}`, url: `${PURPUR}/${ver}/${b}/download` }));
    }
    if (src === 'fabric') {
        const loaders = await getJson(`${FABRIC}/loader`);
        const installers = await getJson(`${FABRIC}/installer`);
        const loader = (loaders.find((l: any) => l.stable) || loaders[0]).version;
        const inst = (installers.find((i: any) => i.stable) || installers[0]).version;
        return [{ id: 'latest', label: `Loader ${loader}`, url: `${FABRIC}/loader/${ver}/${loader}/${inst}/server/jar` }];
    }
    if (src === 'vanilla') {
        const man = await getJson(MOJANG);
        const entry = man.versions.find((v: any) => v.id === ver);
        const meta = await getJson(entry.url);
        return [{ id: 'release', label: 'Mojang release', url: meta.downloads.server.url }];
    }
    const builds = await getJson(`${FILL}/${src}/versions/${ver}/builds`);
    return builds
        .filter((b: any) => b.downloads?.['server:default']?.url)
        .map((b: any) => ({
            id: String(b.id),
            label: `Build ${b.id} · ${b.channel}${b.time ? ` · ${String(b.time).slice(0, 10)}` : ''}`,
            url: b.downloads['server:default'].url,
        }));
};

export default () => {
    const uuid = ServerContext.useStoreState((s) => s.server.data!.uuid);
    const status = ServerContext.useStoreState((s) => s.status.value);
    const [src, setSrc] = useState('paper');
    const [versions, setVersions] = useState<string[]>([]);
    const [ver, setVer] = useState('');
    const [builds, setBuilds] = useState<Build[]>([]);
    const [build, setBuild] = useState('');
    const [jar, setJar] = useState('server.jar');
    const [eula, setEula] = useState(true);
    const [setVar, setSetVar] = useState(true);
    const [msg, setMsg] = useState('');
    const [busy, setBusy] = useState(false);
    const [jars, setJars] = useState<any[]>([]);
    const [current, setCurrent] = useState('');

    const loadJars = async () => {
        try { setJars((await listDir(uuid, '/')).filter((f) => f.is_file && /\.jar(\.bak)?$/i.test(f.name))); } catch { setJars([]); }
        try { setCurrent(JSON.parse(await readText(uuid, '/version_history.json')).currentVersion || ''); } catch { setCurrent(''); }
    };

    useEffect(() => { loadJars(); }, []);

    useEffect(() => {
        setVersions([]); setVer(''); setBuilds([]); setMsg('');
        listVersions(src)
            .then((l) => { const u = Array.from(new Set(l)).sort(newestFirst); setVersions(u); setVer(u[0] || ''); })
            .catch((e) => setMsg(`Could not load versions: ${errMsg(e)}`));
    }, [src]);

    useEffect(() => {
        if (!ver) return;
        setBuilds([]); setBuild('');
        listBuilds(src, ver)
            .then((b) => {
                setBuilds(b);
                const stable = b.find((x) => /STABLE|Build|Loader|Mojang/.test(x.label) && !/ALPHA|BETA|EXPERIMENTAL/.test(x.label));
                setBuild((stable || b[0])?.id || '');
            })
            .catch((e) => setMsg(`Could not load builds: ${errMsg(e)}`));
    }, [ver]);

    if (!enabled('software')) return <PageContentBlock title={'Software Manager'}><p>{Disabled}</p></PageContentBlock>;

    const offline = !status || status === 'offline';

    const install = async () => {
        const chosen = builds.find((b) => b.id === build);
        if (!chosen?.url) return setMsg('Pick a version and build first.');
        if (!/^[A-Za-z0-9_.-]+\.jar$/.test(jar)) return setMsg('Jar filename must end in .jar');
        if (!window.confirm(`Install ${src} ${ver} (${chosen.label}) as ${jar}? The current ${jar} is kept as ${jar}.bak.`)) return;
        setBusy(true);
        try {
            setMsg('Preparing…');
            if (jars.some((j) => j.name === jar)) {
                try { await remove(uuid, '/', [`${jar}.bak`]); } catch { /* no old backup */ }
                await rename(uuid, '/', jar, `${jar}.bak`);
            }
            setMsg('Downloading…');
            await pull(uuid, chosen.url, '/', jar);
            if (eula && src !== 'velocity') { try { await writeText(uuid, '/eula.txt', 'eula=true\n'); } catch { /* ignore */ } }
            if (setVar) { try { await setVariable(uuid, 'SERVER_JARFILE', jar); } catch { /* egg has no such variable */ } }
            setMsg(`Installed ${src} ${ver} as ${jar}. Start the server to use it.`);
            loadJars();
        } catch (e) {
            setMsg(`Install failed: ${errMsg(e)}`);
        }
        setBusy(false);
    };

    const restore = async (bak: string) => {
        const dest = bak.replace(/\.bak$/, '');
        if (!window.confirm(`Restore ${bak} as ${dest}?`)) return;
        try {
            if (jars.some((j) => j.name === dest)) await remove(uuid, '/', [dest]);
            await rename(uuid, '/', bak, dest);
            setMsg(`Restored ${dest}.`);
            loadJars();
        } catch (e) {
            setMsg(`Restore failed: ${errMsg(e)}`);
        }
    };

    return (
        <PageContentBlock title={'Software Manager'}>
            <div className={'bd-card'}>
                <strong>Current</strong>
                <p style={{ opacity: 0.85 }}>{current || 'Version not detected (shown for Paper-based servers after first start).'}</p>
                {jars.map((j) => (
                    <div key={j.name} style={{ display: 'flex', justifyContent: 'space-between', marginTop: '.4rem' }}>
                        <span>{j.name} <span style={{ opacity: 0.6 }}>({fmtSize(j.size)})</span></span>
                        {j.name.endsWith('.bak') && <button className={'bd-btn'} disabled={!offline} onClick={() => restore(j.name)}>Restore</button>}
                    </div>
                ))}
            </div>
            <div className={'bd-card'}>
                {!offline && <p style={{ marginBottom: '.75rem' }}>Stop the server before changing software.</p>}
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '.5rem' }}>
                    <select className={'bd-input'} value={src} onChange={(e) => setSrc(e.target.value)}>
                        {SOURCES.map(([id, label]) => <option key={id} value={id}>{label}</option>)}
                    </select>
                    <select className={'bd-input'} value={ver} onChange={(e) => setVer(e.target.value)}>
                        {versions.map((v) => <option key={v}>{v}</option>)}
                    </select>
                    <select className={'bd-input'} value={build} onChange={(e) => setBuild(e.target.value)}>
                        {builds.map((b) => <option key={b.id} value={b.id}>{b.label}</option>)}
                    </select>
                    <input className={'bd-input'} style={{ width: '10rem' }} value={jar} onChange={(e) => setJar(e.target.value.trim())} />
                </div>
                <div style={{ marginTop: '.75rem', display: 'flex', gap: '1.5rem', flexWrap: 'wrap' }}>
                    <label><input type={'checkbox'} checked={eula} onChange={(e) => setEula(e.target.checked)} /> Accept Minecraft EULA</label>
                    <label><input type={'checkbox'} checked={setVar} onChange={(e) => setSetVar(e.target.checked)} /> Set startup jar variable</label>
                </div>
                <button className={'bd-btn'} style={{ marginTop: '.75rem' }} disabled={busy || !offline || !build} onClick={install}>
                    {busy ? 'Working…' : 'Install'}
                </button>
                {msg && <p style={{ marginTop: '.75rem' }}>{msg}</p>}
                <p style={{ marginTop: '.75rem', opacity: 0.6, fontSize: '.8rem' }}>
                    By installing you accept the Minecraft EULA (minecraft.net/eula). Fabric gets the launcher jar; mods go in /mods.
                </p>
            </div>
        </PageContentBlock>
    );
};

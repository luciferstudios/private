import http from '@/api/http';

// Feature flags injected by wrapper.blade.php (window.BD). Missing = enabled.
export const enabled = (key: string): boolean => {
    const b = (window as any).BD;
    return !b || b[key] !== false;
};

export const errMsg = (e: any): string =>
    e?.response?.data?.errors?.[0]?.detail || e?.message || 'Unknown error';

const base = (uuid: string) => `/api/client/servers/${uuid}`;

export const mkdir = (uuid: string, root: string, dir: string) =>
    http.post(`${base(uuid)}/files/create-folder`, { root, name: dir });

export const remove = (uuid: string, root: string, files: string[]) =>
    http.post(`${base(uuid)}/files/delete`, { root, files });

export const pull = (uuid: string, url: string, directory: string, filename: string) =>
    http.post(`${base(uuid)}/files/pull`, { url, directory, filename, use_header: false, foreground: true });

export const sendCommand = (uuid: string, command: string) =>
    http.post(`${base(uuid)}/command`, { command });

export const listDir = async (uuid: string, directory: string): Promise<any[]> => {
    const r = await http.get(`${base(uuid)}/files/list`, { params: { directory } });
    return r.data.data.map((f: any) => f.attributes);
};

export const readText = async (uuid: string, file: string): Promise<string> => {
    const r = await http.get(`${base(uuid)}/files/contents`, {
        params: { file },
        transformResponse: (res: any) => res,
        responseType: 'text',
    });
    return r.data;
};

// Compare dotted versions numerically, newest first.
export const newestFirst = (a: string, b: string): number => {
    const pa = a.split(/[.-]/).map((x) => parseInt(x, 10) || 0);
    const pb = b.split(/[.-]/).map((x) => parseInt(x, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
        const d = (pb[i] || 0) - (pa[i] || 0);
        if (d !== 0) return d;
    }
    return 0;
};

export const Disabled = 'This feature is disabled by an administrator.';

export const readBinary = async (uuid: string, file: string): Promise<ArrayBuffer> =>
    (await http.get(`${base(uuid)}/files/contents`, {
        params: { file },
        responseType: 'arraybuffer',
        transformResponse: (res: any) => res,
    })).data;

export const writeText = (uuid: string, file: string, text: string) =>
    http.post(`${base(uuid)}/files/write`, text, { params: { file }, headers: { 'Content-Type': 'text/plain' } });

export const rename = (uuid: string, root: string, from: string, to: string) =>
    http.put(`${base(uuid)}/files/rename`, { root, files: [{ from, to }] });

export const setVariable = (uuid: string, key: string, value: string) =>
    http.put(`${base(uuid)}/startup/variable`, { key, value });
